#!/usr/bin/env python

"""
A filter that splits text into one word per line.
"""

import fileinput


def process(line):
    """For each line of input, split into one word per line."""  
    exclude = set(['and','the','to','of','her','it','in','you','she','for'])
    list = ''.join(ch for ch in line if ch not in exclude)
    print (list)
    

for line in fileinput.input():
    process(line)
