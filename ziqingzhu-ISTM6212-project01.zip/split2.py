#!/usr/bin/env python

"""
A filter that lowers characters.
"""

import fileinput
import re

def process(line):
    """For each line of input, split all characters."""
    ch = re.compile('\w+')
    line = ch.findall(line)
    for ch in line:
        if len(ch)>=2:
            print (ch)


for line in fileinput.input():
    process(line)
