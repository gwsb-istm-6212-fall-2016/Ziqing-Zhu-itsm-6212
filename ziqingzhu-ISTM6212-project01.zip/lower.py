#!/usr/bin/env python

"""
A filter that lowers characters.
"""

import fileinput


def process(line):
    """For each line of input, lower all characters."""
    print(line.lower())


for line in fileinput.input():
    process(line)
